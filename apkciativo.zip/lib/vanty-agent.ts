// lib/vanty-agent.ts
// El Agente IA de Vanty — cerebro clínico con memoria, herramientas y análisis proactivo

import { supabaseAdmin } from '@/lib/supabase-admin'
import { buildKnowledgeContext, searchKnowledge } from '@/lib/knowledge-base'
import { getChildHistory } from '@/lib/child-history'
import { callGroq, callGroqSimple, GROQ_MODELS } from '@/lib/groq-client'



// ── Herramientas del agente ──────────────────────────────────────────────────

const AGENT_TOOLS = {
  // Buscar en base de conocimiento
  async buscarConocimiento(query: string) {
    const results = await searchKnowledge(query, { maxResults: 4, threshold: 0.6 })
    return results.length > 0
      ? results.map(r => `[${r.fuente}]: ${r.contenido}`).join('\n\n')
      : 'No se encontró información específica sobre este tema en la base de conocimiento.'
  },

  // Obtener datos de un programa ABA
  async obtenerDatosPrograma(programaId: string) {
    const { data: programa } = await supabaseAdmin
      .from('programas_aba')
      .select('*, sesiones_datos_aba(fecha, porcentaje_exito, frecuencia_valor, fase, notas, nivel_ayuda)')
      .eq('id', programaId)
      .order('sesiones_datos_aba.fecha', { ascending: true })
      .single()

    if (!programa) return 'Programa no encontrado.'

    const sesiones = (programa as any).sesiones_datos_aba || []
    const tendencia = await calcularTendenciaLocal(sesiones)

    return JSON.stringify({
      titulo: (programa as any).titulo,
      area: (programa as any).area,
      fase_actual: (programa as any).fase_actual,
      estado: (programa as any).estado,
      criterio_dominio: `${(programa as any).criterio_dominio_pct}% en ${(programa as any).criterio_sesiones_consecutivas} sesiones`,
      total_sesiones: sesiones.length,
      ultima_sesion: sesiones[sesiones.length - 1],
      tendencia,
      sesiones_recientes: sesiones.slice(-5),
    }, null, 2)
  },

  // Obtener todos los programas de un niño
  async obtenerProgramasNino(childId: string) {
    const { data } = await supabaseAdmin
      .from('programas_aba')
      .select(`
        id, titulo, area, estado, fase_actual,
        sesiones_datos_aba(porcentaje_exito, fecha)
      `)
      .eq('child_id', childId)
      .eq('estado', 'activo')
      .order('created_at', { ascending: false })

    if (!data || data.length === 0) return 'No hay programas activos para este paciente.'

    return (data as any[]).map(p => {
      const sesiones = p.sesiones_datos_aba || []
      const ultimoPct = sesiones.length > 0
        ? sesiones[sesiones.length - 1]?.porcentaje_exito
        : null
      return `- ${p.titulo} (${p.area}) | Fase: ${p.fase_actual} | Último %: ${ultimoPct ?? 'sin datos'}`
    }).join('\n')
  },

  // Historial clínico del niño
  async obtenerHistorialNino(childId: string) {
    const history = await getChildHistory(childId)
    return `Paciente: ${history.nombre}, ${history.edad}\nDiagnóstico: ${history.diagnostico}\n${history.historialTexto}`
  },

  // FIX: Resumen de TODOS los pacientes para preguntas generales
  async obtenerResumenTodosPacientes() {
    const { data: pacientes } = await supabaseAdmin
      .from('children')
      .select('id, name, age, birth_date, diagnosis, status')
      .order('name', { ascending: true })
      .limit(50)

    if (!pacientes || pacientes.length === 0) return 'No hay pacientes registrados en el sistema.'

    const resumenes: string[] = []

    for (const p of pacientes as any[]) {
      // FIX: Priorizar birth_date (preciso) sobre age guardado (puede estar desactualizado)
      let edadTexto = 'edad N/E'
      if (p.birth_date) {
        const hoy = new Date()
        const nac = new Date(p.birth_date)
        const diff = hoy.getFullYear() - nac.getFullYear()
        const m = hoy.getMonth() - nac.getMonth()
        const edad = (m < 0 || (m === 0 && hoy.getDate() < nac.getDate())) ? diff - 1 : diff
        edadTexto = `${edad} años`
      } else if (p.age) {
        const numAge = parseInt(String(p.age).replace(/[^0-9]/g, ''), 10)
        edadTexto = !isNaN(numAge) ? `${numAge} años` : 'edad N/E'
      }

      // Última sesión ABA
      const { data: ultimaSesion } = await supabaseAdmin
        .from('registro_aba')
        .select('fecha_sesion, datos')
        .eq('child_id', p.id)
        .order('fecha_sesion', { ascending: false })
        .limit(1)
        .maybeSingle()

      // Programas activos
      const { data: programas } = await supabaseAdmin
        .from('programas_aba')
        .select('id, titulo, estado')
        .eq('child_id', p.id)
        .eq('estado', 'activo')
        .limit(3)

      // Alertas activas
      const { data: alertas } = await supabaseAdmin
        .from('agente_alertas')
        .select('tipo, prioridad')
        .eq('child_id', p.id)
        .eq('resuelta', false)
        .limit(5)

      const alertasAltas = (alertas || []).filter((a: any) => a.prioridad === 'alta').length
      const alertasMedia = (alertas || []).filter((a: any) => a.prioridad === 'media').length

      let nivelLogro = 'sin datos'
      if (ultimaSesion && (ultimaSesion as any).datos?.nivel_logro_objetivos) {
        const val = (ultimaSesion as any).datos.nivel_logro_objetivos
        nivelLogro = typeof val === 'string' && val.includes('-') ? val : `${val}%`
      }

      const diasSinSesion = ultimaSesion
        ? Math.floor((Date.now() - new Date((ultimaSesion as any).fecha_sesion).getTime()) / 86400000)
        : null

      resumenes.push(
        `PACIENTE: ${p.name} | ${edadTexto} | Dx: ${p.diagnosis || 'No especificado'}\n` +
        `  Última sesión: ${ultimaSesion ? (ultimaSesion as any).fecha_sesion + (diasSinSesion !== null ? ` (hace ${diasSinSesion} días)` : '') : 'ninguna registrada'}\n` +
        `  Último logro de objetivos: ${nivelLogro}\n` +
        `  Programas ABA activos: ${programas?.length || 0}${programas && programas.length > 0 ? ' (' + (programas as any[]).map(pr => pr.titulo).join(', ') + ')' : ''}\n` +
        `  Alertas activas: ${(alertas || []).length}${alertasAltas > 0 ? ` (${alertasAltas} ALTA prioridad)` : ''}${alertasMedia > 0 ? ` (${alertasMedia} media)` : ''}`
      )
    }

    return `RESUMEN DEL SISTEMA — ${pacientes.length} PACIENTES ACTIVOS:\n\n${resumenes.join('\n\n')}`
  },

  // Analizar tendencia de un programa
  async analizarTendencia(programaId: string, ultimasN: number = 5) {
    const { data } = await supabaseAdmin
      .rpc('calcular_tendencia_programa', { prog_id: programaId, ultimas_n: ultimasN })
    return JSON.stringify(data)
  },
}

// ── Calcular tendencia localmente ────────────────────────────────────────────
function calcularTendenciaLocal(sesiones: any[]) {
  if (sesiones.length < 2) return { tendencia: 'insuficiente', mensaje: 'Pocas sesiones' }

  const recientes = sesiones.slice(-5).map(s => s.porcentaje_exito).filter(Boolean)
  const anteriores = sesiones.slice(-10, -5).map(s => s.porcentaje_exito).filter(Boolean)

  if (recientes.length === 0) return { tendencia: 'sin_datos', mensaje: 'Sin datos de %' }

  const promReciente = recientes.reduce((a, b) => a + b, 0) / recientes.length
  const promAnterior = anteriores.length > 0
    ? anteriores.reduce((a, b) => a + b, 0) / anteriores.length
    : promReciente

  const cambio = promReciente - promAnterior

  return {
    promedio_reciente: Math.round(promReciente),
    promedio_anterior: Math.round(promAnterior),
    cambio: Math.round(cambio),
    tendencia: cambio > 5 ? 'mejorando' : cambio < -5 ? 'regresion' : 'estable',
  }
}

// ── Sistema prompt del agente ─────────────────────────────────────────────────

// Helper para obtener el nombre del idioma para el prompt de ARIA
function getLocaleLabel(locale: string): string {
  const labels: Record<string, string> = {
    es: 'español',
    en: 'English',
    pt: 'português',
    fr: 'français',
    de: 'Deutsch',
    it: 'italiano',
  }
  return labels[locale] || 'español'
}

// El system prompt base de ARIA — el idioma se agrega dinámicamente según el locale del usuario
const SYSTEM_PROMPT_BASE = `Eres ARIA, asistente clínica de Vanty 🧠 — plataforma de intervención infantil especializada en ABA, TEA, TDAH y neurodesarrollo.

🎯 IDENTIDAD:
Estoy entrenada en evaluación e intervención de población infantil, con base en ABA (Cooper, Heron & Heward; Malott & Trojan), ética clínica IBAO/BACB, neuropsicología del neurodesarrollo, educación especial y el Journal of Applied Behavior Analysis (JABA). Hablo español clínico, cálido y profesional — dirigido a terapeutas y supervisoras, NUNCA al paciente infantil directamente.

📚 FUENTES VÁLIDAS:
- Cooper, Heron & Heward — Applied Behavior Analysis
- Richard Malott — Principles of Behavior
- DSM-5-TR (APA, 2022)
- CIE-11 / ICD-11 (OMS, 2022) — Clasificación Internacional de Enfermedades 11ª Revisión
- BACB Task List / IBAO Guidelines
- Journal of Applied Behavior Analysis (JABA)
- Behavior Analysis in Practice (BAP)
- Scopus / Web of Science (artículos peer-reviewed ABA)
⛔ NUNCA uses Wikipedia, blogs, ni fuentes no revisadas por pares.

🏥 DIAGNÓSTICOS CIE-11 (DOMINIO SALUD MENTAL Y NEURODESARROLLO):
Cuando se consulte por diagnósticos, puedes buscar en:
- TEA / Trastorno del Espectro Autista → CIE-11: 6A02 | DSM-5: 299.00
- TDAH → CIE-11: 6A05 | DSM-5: 314.xx
- Discapacidad Intelectual → CIE-11: 6A00 | DSM-5: 319
- Trastorno del Desarrollo del Lenguaje → CIE-11: 6A01
- Trastorno del Movimiento Estereotipado → CIE-11: 6A06
- Trastorno por Tics → CIE-11: 8A05
- Ansiedad → CIE-11: 6B00 | DSM-5: 300.02
- TOC → CIE-11: 6B20 | DSM-5: 300.3
- Trastorno de Apego Reactivo → CIE-11: 6B44
- Epilepsia → CIE-11: 8A60-8A6Z
Al citar diagnósticos, SIEMPRE incluye el código CIE-11 y DSM-5 cuando corresponda.

📊 CRITERIO DE LOGRO ABA (REGLA CRÍTICA):
- ✅ LOGRO = paciente alcanza ≥ 90% en mínimo 2 sesiones CONSECUTIVAS dentro del mismo SET
- Siempre reporta: último % registrado + media o mediana del historial (según distribución)
- ⚠️ ALERTA si hay saltos bruscos (ej: 0% → 90% en 1 sesión) = posible error de registro
- Analiza siempre por PROGRAMA/OBJETIVO/SET específico, nunca en general

✍️ FORMATO DE RESPUESTA (SIEMPRE):
- Usa emojis como separadores de sección: 📊 datos · 🎯 objetivos · ⚠️ alertas · 💡 sugerencias · ✅ logros · 🔄 en proceso
- Omite frases de cortesía innecesarias como "Excelente pregunta" o "Claro, con gusto"
- Habla como un especialista clínico — con autoridad, precisión y criterio propio
- Desarrolla las respuestas con la profundidad que el tema requiere: si la pregunta es simple, responde conciso; si es compleja, desarrolla con detalle clínico
- NO cites las fuentes bibliográficas en cada respuesta. El conocimiento ya está integrado. Si mencionas un concepto técnico, nómbralo directamente (ej: "extinción de escape", "moldeamiento", "DRO") sin agregar "(Cooper et al.)" o "(Malott)"
- Solo menciona una fuente si el usuario pregunta explícitamente de dónde viene la información
- Lenguaje técnico-clínico apropiado para terapeutas profesionales, fluido y natural

🗂️ ACCESO A DATOS DEL SISTEMA:
- Si el contexto contiene "RESUMEN DEL SISTEMA" o "HISTORIAL CLÍNICO" → úsalos DIRECTAMENTE
- Nunca digas "no tengo acceso" si los datos están en el contexto
- Para análisis de pacientes: usa alertas, última sesión, % de logro y programas activos del contexto
- Para comparaciones: analiza todos los pacientes del resumen con nombres reales

⚖️ REGLAS:
- NUNCA inventes datos que no estén en el contexto
- NUNCA respondas con evasivas genéricas si tienes datos disponibles
- ARIA es COMPLEMENTO del terapeuta. Las decisiones clínicas (cambiar programas, objetivos, estrategias) SIEMPRE las toma el especialista certificado. Si te piden tomar una decisión clínica, sugiere opciones pero derivá siempre al terapeuta
- NUNCA sugieras modificar el programa terapéutico vigente sin indicar que debe ser validado por el especialista
- Si hay dilema ético: aplica el modelo de 7 pasos IBAO
- Si preguntan por el nombre del sistema: es VANTY, no mencionas "Jugando Aprendo" en respuestas clínicas
- Cuando analices tendencias, considera el contexto clínico COMPLETO del paciente`

// ── Clase principal del Agente ────────────────────────────────────────────────

// i18n: responder en el idioma del usuario
function getLangInstruction(locale: string): string {
  return ''
}

export class VantyAgent {
  private conversacionId: string | null = null

  // Iniciar o continuar una conversación
  async chat(
    userMessage: string,
    options: {
      childId?: string
      userId: string
      conversacionId?: string
      contexto?: string
      locale?: string
    }
  ): Promise<AgentResponse> {
    const startTime = Date.now()

    try {
      // 1. Cargar o crear conversación
      let conversacion = await this.loadOrCreateConversacion(
        options.conversacionId,
        options.userId,
        options.childId,
        options.contexto
      )

      // 2. Construir contexto dinámico
      // FIX: detectar preguntas sobre pacientes para cargar datos del sistema
      const preguntaSobrePacientes = /paciente|peor|mejor|progreso|todos|lista|quien|quién|comparar|estado|sesion|sesión|avance|regresion|regresión|alert/i.test(userMessage)

      const [knowledgeCtx, childCtx, globalCtx] = await Promise.all([
        buildKnowledgeContext(userMessage),
        options.childId ? AGENT_TOOLS.obtenerHistorialNino(options.childId) : Promise.resolve(''),
        // FIX: Si no hay paciente específico pero preguntan sobre pacientes, cargar todos
        (!options.childId && preguntaSobrePacientes)
          ? AGENT_TOOLS.obtenerResumenTodosPacientes()
          : Promise.resolve(''),
      ])

      // 3. Preparar mensajes con historial (formato Groq/OpenAI)
      const messages = conversacion.mensajes as any[]
      const historialReciente = messages.slice(-10)

      // Construir contexto completo
      // Detectar idioma del usuario y ajustar respuesta de ARIA
      const userLocale = (options as any).locale || 'es'
      const localeInstruction = userLocale !== 'es' 
        ? `\n\n[IDIOMA OBLIGATORIO: Responde SIEMPRE en ${getLocaleLabel(userLocale)}. Nunca respondas en español si el idioma configurado es diferente.]`
        : ''
      let systemContext = SYSTEM_PROMPT_BASE + localeInstruction + '\n\n' + knowledgeCtx
      if (childCtx) systemContext += '\nPACIENTE ACTIVO:\n' + childCtx
      if (globalCtx) systemContext += '\n\n' + globalCtx

      const groqMessages = [
        { role: 'system' as const, content: systemContext },
        ...historialReciente.map((m: any) => ({ role: m.role as 'user' | 'assistant', content: m.content })),
        { role: 'user' as const, content: userMessage },
      ]

      // 4. Llamar a Groq (gratis, rápido)
      const aiResponse = await callGroq(groqMessages, {
        model: GROQ_MODELS.SMART,
        temperature: 0.6,
        maxTokens: 2000,
      }) || 'No pude generar una respuesta.'

      // 6. Detectar si necesita usar herramientas
      const toolResult = await this.detectAndUseTool(userMessage, aiResponse, options.childId)
      const finalResponse = toolResult ? `${aiResponse}\n\n${toolResult}` : aiResponse

      // 7. Guardar en historial
      const updatedMessages = [
        ...messages,
        { role: 'user', content: userMessage, timestamp: new Date().toISOString() },
        { role: 'assistant', content: finalResponse, timestamp: new Date().toISOString() },
      ]

      await supabaseAdmin
        .from('agente_conversaciones')
        .update({
          mensajes: updatedMessages,
          updated_at: new Date().toISOString(),
        })
        .eq('id', conversacion.id)

      // 8. Log de acción
      await supabaseAdmin.from('agente_acciones').insert({
        conversacion_id: conversacion.id,
        child_id: options.childId,
        tipo_accion: 'chat',
        input_data: { mensaje: userMessage },
        output_data: { respuesta: finalResponse, tiempo_ms: Date.now() - startTime },
      })

      return {
        respuesta: finalResponse,
        conversacionId: conversacion.id,
        fuentesUsadas: await this.extractSources(finalResponse),
        tiempoMs: Date.now() - startTime,
      }
    } catch (error: any) {
      console.error('Error agente:', error)
      return {
        respuesta: 'Hubo un error procesando tu consulta. Por favor intenta de nuevo.',
        conversacionId: options.conversacionId || null,
        fuentesUsadas: [],
        tiempoMs: Date.now() - startTime,
        error: error.message,
      }
    }
  }

  // Análisis proactivo de un paciente (ejecutar al abrir ficha)
  async analizarPacienteProactivo(childId: string): Promise<ProactiveAnalysis> {
    try {
      // Obtener todos los programas activos
      const { data: programas } = await supabaseAdmin
        .from('programas_aba')
        .select(`
          id, titulo, area, fase_actual, criterio_dominio_pct,
          sesiones_datos_aba(fecha, porcentaje_exito, fase)
        `)
        .eq('child_id', childId)
        .eq('estado', 'activo')

      if (!programas || programas.length === 0) {
        return { alertas: [], sugerencias: [], resumen: 'No hay programas activos para analizar.' }
      }

      const alertas: Alerta[] = []
      const sugerencias: string[] = []

      for (const prog of programas as any[]) {
        const sesiones = prog.sesiones_datos_aba || []
        if (sesiones.length < 2) continue

        const tendencia = calcularTendenciaLocal(sesiones)

        // Detectar regresión
        if (tendencia.tendencia === 'regresion' && (tendencia.cambio || 0) < -10) {
          alertas.push({
            tipo: 'regresion',
            titulo: `Regresión en "${prog.titulo}"`,
            mensaje: `El % de éxito bajó ${Math.abs(tendencia.cambio || 0)}% en las últimas sesiones (${tendencia.promedio_anterior}% → ${tendencia.promedio_reciente}%). Revisar antecedentes y reforzadores.`,
            prioridad: 'alta',
            programa_id: prog.id,
          })
        }

        // Detectar estancamiento (>5 sesiones sin cambio)
        if (sesiones.length >= 5 && tendencia.tendencia === 'estable' && (tendencia.promedio_reciente || 0) < 70) {
          alertas.push({
            tipo: 'estancamiento',
            titulo: `Estancamiento en "${prog.titulo}"`,
            mensaje: `Lleva ${sesiones.length} sesiones con promedio estable de ${tendencia.promedio_reciente}%. Considera revisar el procedimiento o nivel de ayuda.`,
            prioridad: 'media',
            programa_id: prog.id,
          })
        }

        // Detectar criterio próximo a cumplirse
        if ((tendencia.promedio_reciente || 0) >= prog.criterio_dominio_pct - 5) {
          sugerencias.push(`"${prog.titulo}" está al ${tendencia.promedio_reciente}% — cerca del criterio de dominio (${prog.criterio_dominio_pct}%). ¡Excelente progreso!`)
        }

        // Sin sesiones en 7+ días
        const ultimaFecha = sesiones[sesiones.length - 1]?.fecha
        if (ultimaFecha) {
          const diasSinSesion = Math.floor((Date.now() - new Date(ultimaFecha).getTime()) / 86400000)
          if (diasSinSesion >= 7) {
            alertas.push({
              tipo: 'sin_sesion',
              titulo: `Sin sesión hace ${diasSinSesion} días — "${prog.titulo}"`,
              mensaje: `El programa no ha tenido sesiones en ${diasSinSesion} días. Verificar si hay ausencia del paciente o cambio de prioridades.`,
              prioridad: diasSinSesion >= 14 ? 'alta' : 'baja',
              programa_id: prog.id,
            })
          }
        }
      }

      // Guardar alertas nuevas en BD
      if (alertas.length > 0) {
        await supabaseAdmin.from('agente_alertas').upsert(
          alertas.map(a => ({
            child_id: childId,
            tipo: a.tipo,
            titulo: a.titulo,
            mensaje: a.mensaje,
            programa_id: a.programa_id,
            prioridad: a.prioridad,
            resuelta: false,
          }))
        )
      }

      // Resumen general con IA
      const childHistory = await getChildHistory(childId)
      const resumenPrompt = `Eres ARIA, analista de conducta. Resume el estado clínico actual de ${childHistory.nombre} en 2-3 oraciones basándote en estos datos:
      - ${programas.length} programas activos
      - Alertas detectadas: ${alertas.map(a => a.titulo).join(', ') || 'ninguna'}
      - Avances cercanos al criterio: ${sugerencias.join(', ') || 'ninguno'}
      Sé específico, clínico y menciona el nombre del paciente.`

      const resumenText = await callGroqSimple('Eres ARIA, analista de conducta clínica.', resumenPrompt, { model: GROQ_MODELS.SMART, temperature: 0.4, maxTokens: 300 })

      return {
        alertas,
        sugerencias,
        resumen: resumenText || 'Análisis completado.',
      }
    } catch (error: any) {
      console.error('Error análisis proactivo:', error)
      return { alertas: [], sugerencias: [], resumen: 'Error al analizar el paciente.' }
    }
  }

  // Detectar si la pregunta requiere usar una herramienta
  private async detectAndUseTool(
    userMessage: string,
    aiResponse: string,
    childId?: string
  ): Promise<string | null> {
    const msg = userMessage.toLowerCase()

    // Con paciente específico: mostrar programas activos
    if ((msg.includes('tendencia') || msg.includes('progreso') || msg.includes('programa')) && childId) {
      const programas = await AGENT_TOOLS.obtenerProgramasNino(childId)
      if (programas !== 'No hay programas activos para este paciente.') {
        return `\n**Programas ABA activos:**\n${programas}`
      }
    }

    // FIX: Sin paciente, preguntas sobre quién está peor/mejor → ya se maneja en el contexto
    // Si la respuesta de la IA aún dice "no tengo acceso", forzar la carga
    if (!childId && (
      aiResponse.includes('no tengo acceso') ||
      aiResponse.includes('no puedo proporcionar') ||
      aiResponse.includes('sin acceso')
    ) && /paciente|peor|mejor|progreso|estado/i.test(msg)) {
      const resumen = await AGENT_TOOLS.obtenerResumenTodosPacientes()
      return `\n**Datos del sistema (respuesta directa):**\n${resumen}`
    }

    return null
  }

  // Extraer fuentes mencionadas en la respuesta
  private async extractSources(response: string): Promise<string[]> {
    const sources: string[] = []
    const patterns = [/Malott/i, /DSM-5/i, /IBAO/i, /LuTr/i, /IBA/i]
    patterns.forEach(p => {
      if (p.test(response)) sources.push(p.source.replace(/[/i]/g, ''))
    })
    return sources
  }

  // Cargar o crear conversación
  private async loadOrCreateConversacion(
    conversacionId?: string,
    userId?: string,
    childId?: string,
    contexto?: string
  ) {
    if (conversacionId) {
      const { data } = await supabaseAdmin
        .from('agente_conversaciones')
        .select('*')
        .eq('id', conversacionId)
        .single()
      if (data) return data
    }

    const { data } = await supabaseAdmin
      .from('agente_conversaciones')
      .insert({
        user_id: userId,
        child_id: childId,
        contexto: contexto || 'general',
        mensajes: [],
        titulo: `Consulta ${new Date().toLocaleDateString('es-PE')}`,
      })
      .select()
      .single()

    return data!
  }
}

// ── Tipos ────────────────────────────────────────────────────────────────────
export interface AgentResponse {
  respuesta: string
  conversacionId: string | null
  fuentesUsadas: string[]
  tiempoMs: number
  error?: string
}

export interface Alerta {
  tipo: string
  titulo: string
  mensaje: string
  prioridad: 'alta' | 'media' | 'baja'
  programa_id?: string
}

export interface ProactiveAnalysis {
  alertas: Alerta[]
  sugerencias: string[]
  resumen: string
}

// Instancia singleton
export const vantyAgent = new VantyAgent()
